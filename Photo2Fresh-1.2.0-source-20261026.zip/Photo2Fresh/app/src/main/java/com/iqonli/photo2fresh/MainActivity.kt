package com.iqonli.photo2fresh

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.iqonli.photo2fresh.ui.Photo2FreshApp
import com.iqonli.photo2fresh.ui.theme.Photo2freshTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Photo2freshTheme {
                Photo2FreshApp()
            }
        }
    }
}
